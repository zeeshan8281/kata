# @layr-labs/eigen-design

Shared React component library and design system for EigenLayer applications.

## Stack

- **React 19** — function components, no `forwardRef`
- **Tailwind CSS v4** — CSS-first config, design tokens via `@theme`
- **shadcn/ui v4** — component base, customized with Figma design system
- **tsup** — ESM + CJS dual output
- **Storybook** — component development and preview

## Installation

Published to **GitHub Packages** (private, org-scoped).

### 1. Configure `.npmrc`

```
@layr-labs:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Set `GITHUB_TOKEN` in your environment with a PAT that has `read:packages` scope and is authorized for the `Layr-Labs` org.

### 2. Install

```bash
pnpm add @layr-labs/eigen-design
```

### 3. Configure your app

```css
/* app/globals.css */
@import "tailwindcss";
@source "@layr-labs/eigen-design/dist";
@import "@layr-labs/eigen-design/styles";
```

See [skills.md](./skills.md) for full setup instructions including font loading.

## Development

```bash
pnpm dev           # Start Storybook on port 6006
pnpm build         # Build library to dist/
pnpm build:watch   # Build with file watching
pnpm typecheck     # Run TypeScript type checking
```

## Publishing

A GitHub Actions workflow auto-publishes to GitHub Packages when a version tag is pushed.

```bash
pnpm version patch   # or minor / major
git push && git push --tags
```

The workflow uses the built-in `GITHUB_TOKEN` — no manual secret configuration needed.

## Claude Code Plugin

This repo is also a Claude Code plugin, distributed via the [`Layr-Labs/claude-plugins`](https://github.com/Layr-Labs/claude-plugins) marketplace.

### Install the plugin

```
/plugin marketplace add Layr-Labs/claude-plugins
/plugin install eigen-design@layr-labs-tools
```

### Use the skill

```
/eigen-design:design-system
```

This teaches Claude how to use the component library — available components, design tokens, setup instructions, and patterns.

### Auto-setup for repos

Add to `.claude/settings.json` in any consuming repo:

```json
{
  "extraKnownMarketplaces": {
    "layr-labs-tools": {
      "source": {
        "source": "github",
        "repo": "Layr-Labs/claude-plugins"
      }
    }
  },
  "enabledPlugins": {
    "eigen-design@layr-labs-tools": true
  }
}
```
